$('document').ready(function () {

 
});
