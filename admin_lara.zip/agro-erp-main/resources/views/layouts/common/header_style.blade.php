<!--favicon-->
<link rel="icon" href="{{ asset('public/assets/images/favicon.ico') }}" type="image/x-icon">
<!-- notifications css -->
<link rel="stylesheet" href="{{ asset('public/assets/plugins/notifications/css/lobibox.min.css') }}" />
<!-- Vector CSS -->
<link href="{{ asset('public/assets/plugins/vectormap/jquery-jvectormap-2.0.2.css') }}" rel="stylesheet" />
<!-- simplebar CSS-->
<link href="{{ asset('public/assets/plugins/simplebar/css/simplebar.css') }}" rel="stylesheet" />
<!-- Bootstrap core CSS-->
<link href="{{ asset('public/assets/css/bootstrap.min.css') }}" rel="stylesheet" />
<!-- animate CSS-->
<link href="{{ asset('public/assets/css/animate.css') }}" rel="stylesheet" type="text/css" />
<!-- Icons CSS-->
<link href="{{ asset('public/assets/css/icons.css') }}" rel="stylesheet" type="text/css" />
<!-- Sidebar CSS-->
<link href="{{ asset('public/assets/css/sidebar-menu.css') }}" rel="stylesheet" />
<!-- Custom Style-->
<link href="{{ asset('public/assets/css/app-style.css') }}" rel="stylesheet" />
<link href="{{ asset('public/assets/css/custom.css') }}" rel="stylesheet" />
<!-- Date Style-->
<link rel="stylesheet" href="{{ asset('public/assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css') }}" />

<link href="{{ asset('public/assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css') }}" rel="stylesheet" />
<link href="{{ asset('public/assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css') }}" rel="stylesheet" />
<link href="{{ asset('public/assets/plugins/bootstrap-datatable/css/buttons.dataTables.min.css') }}" rel="stylesheet" />

<link href="{{ asset('public/assets/plugins/select2/css/select2.min.css') }}" rel="stylesheet" />
