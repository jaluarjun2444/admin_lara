<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->

<!--Start footer-->
<div style="min-height:34.5vh;">
    <footer class="footer">
        <div class="container">
            <div class="text-center">
                Copyright © 2021-<?php echo date('Y'); ?>
            </div>
        </div>
    </footer>
</div>
<!--End footer-->

