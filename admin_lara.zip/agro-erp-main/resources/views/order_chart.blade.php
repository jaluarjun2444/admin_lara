<div class="card">
    <div class="card-header text-uppercase">Sales Chart</div>
    <div class="card-body">
      <canvas id="barChart"></canvas>
    </div>
  </div>
